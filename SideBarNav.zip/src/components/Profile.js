import React from "react";
//import { useState } from "react";

const Profile = () => {
    
  return (
      <div>
          
        <h4 style={{ color: "black" }}>My Profile</h4>
        <h4 style={{ color: "black" }}>Settings</h4>
        <h4 style={{ color: "black" }}>Logout</h4>
      </div>
    
    
  );
};

export default Profile;
